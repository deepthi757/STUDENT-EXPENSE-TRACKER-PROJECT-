/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import exception.BudgetExceededException;

public class Budget {
    private int budgetId;
    private int studentId;
    private int budgetMonth;
    private int budgetYear;
    private double limitAmount;

    public Budget() {
    }

    public Budget(int budgetId, int studentId, int budgetMonth, int budgetYear, double limitAmount) {
        this.budgetId = budgetId;
        this.studentId = studentId;
        this.budgetMonth = budgetMonth;
        this.budgetYear = budgetYear;
        this.limitAmount = limitAmount;
    }

    public int getBudgetId() { return budgetId; }
    public void setBudgetId(int budgetId) { this.budgetId = budgetId; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getBudgetMonth() { return budgetMonth; }
    public void setBudgetMonth(int budgetMonth) { this.budgetMonth = budgetMonth; }

    public int getBudgetYear() { return budgetYear; }
    public void setBudgetYear(int budgetYear) { this.budgetYear = budgetYear; }

    public double getLimitAmount() { return limitAmount; }
    public void setLimitAmount(double limitAmount) { this.limitAmount = limitAmount; }

    public double getRemaining(double totalSpent) {
        return limitAmount - totalSpent;
    }

    public void checkBudget(double totalSpent) throws BudgetExceededException {
        if (totalSpent > limitAmount) {
            throw new BudgetExceededException(
                    "Budget exceeded! Limit: Rs." + limitAmount + ", Spent: Rs." + totalSpent);
        }
    }
}