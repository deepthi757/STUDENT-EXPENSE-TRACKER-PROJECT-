/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;

public class Expense extends Transaction {
    private int expenseId;
    private int studentId;
    private int categoryId;

    public Expense() {
    }

    public Expense(int expenseId, int studentId, int categoryId,
                   double amount, String description, LocalDate date) {
        super(amount, date, description);
        this.expenseId = expenseId;
        this.studentId = studentId;
        this.categoryId = categoryId;
    }

    public int getExpenseId() { return expenseId; }
    public void setExpenseId(int expenseId) { this.expenseId = expenseId; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }

    @Override
    public String getDetails() {
        return "Expense #" + expenseId + ": Rs." + getAmount()
                + " on " + getDate() + " - " + getDescription();
    }
}