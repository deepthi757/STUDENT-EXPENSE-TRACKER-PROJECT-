/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

public class BudgetExceededException extends Exception {
    private double limit;
    private double spent;

    public BudgetExceededException(String message) {
        super(message);
    }

    public BudgetExceededException(String message, double limit, double spent) {
        super(message);
        this.limit = limit;
        this.spent = spent;
    }

    public double getLimit() { return limit; }
    public double getSpent() { return spent; }
}