/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Model.Expense;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import util.DBConnection;

public class ExpenseDAO {

    // CREATE
    public void addExpense(Expense e) throws SQLException {
        String sql = "INSERT INTO expense (student_id, category_id, amount, description, expense_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getStudentId());
            ps.setInt(2, e.getCategoryId());
            ps.setDouble(3, e.getAmount());
            ps.setString(4, e.getDescription());
            ps.setDate(5, java.sql.Date.valueOf(e.getDate()));
            ps.executeUpdate();
        }
    }

    // READ
    public List<Expense> getAllExpenses() throws SQLException {
        List<Expense> list = new ArrayList<>();
        String sql = "SELECT expense_id, student_id, category_id, amount, description, expense_date FROM expense ORDER BY expense_date DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Expense(
                        rs.getInt("expense_id"),
                        rs.getInt("student_id"),
                        rs.getInt("category_id"),
                        rs.getDouble("amount"),
                        rs.getString("description"),
                        rs.getDate("expense_date").toLocalDate()));
            }
        }
        return list;
    }

    // UPDATE
    public void updateExpense(Expense e) throws SQLException {
        String sql = "UPDATE expense SET category_id = ?, amount = ?, description = ?, expense_date = ? WHERE expense_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, e.getCategoryId());
            ps.setDouble(2, e.getAmount());
            ps.setString(3, e.getDescription());
            ps.setDate(4, java.sql.Date.valueOf(e.getDate()));
            ps.setInt(5, e.getExpenseId());
            ps.executeUpdate();
        }
    }

    // DELETE
    public void deleteExpense(int expenseId) throws SQLException {
        String sql = "DELETE FROM expense WHERE expense_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, expenseId);
            ps.executeUpdate();
        }
    }

    // Monthly total
    public double getMonthlyTotal(int studentId, int month, int year) throws SQLException {
        String sql = "SELECT COALESCE(SUM(amount), 0) FROM expense WHERE student_id = ? AND MONTH(expense_date) = ? AND YEAR(expense_date) = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0;
            }
        }
    }
}