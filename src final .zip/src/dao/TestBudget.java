/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Model.Budget;
import exception.BudgetExceededException;
import java.time.LocalDate;

public class TestBudget {
    public static void main(String[] args) {
        try {
            BudgetDAO budgetDAO = new BudgetDAO();
            ExpenseDAO expenseDAO = new ExpenseDAO();

            LocalDate today = LocalDate.now();
            int month = today.getMonthValue();
            int year = today.getYear();

            budgetDAO.saveBudget(new Budget(0, 1, month, year, 150.0));

            double spent = expenseDAO.getMonthlyTotal(1, month, year);
            Budget b = budgetDAO.getBudget(1, month, year);
            System.out.println("Budget: " + b.getLimitAmount() + ", spent: " + spent);

            if (spent > b.getLimitAmount()) {
                throw new BudgetExceededException(
                        "Budget exceeded by Rs." + (spent - b.getLimitAmount()));
            }
            System.out.println("Within budget");
        } catch (BudgetExceededException ex) {
            System.out.println("WARNING: " + ex.getMessage());
        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }
}
