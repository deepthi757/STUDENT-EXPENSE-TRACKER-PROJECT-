/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Model.Budget;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import util.DBConnection;

public class BudgetDAO {

    // READ: returns null if no budget is set for that month
    public Budget getBudget(int studentId, int month, int year) throws SQLException {
        String sql = "SELECT budget_id, student_id, budget_month, budget_year, limit_amount FROM budget WHERE student_id = ? AND budget_month = ? AND budget_year = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ps.setInt(2, month);
            ps.setInt(3, year);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Budget(
                            rs.getInt("budget_id"),
                            rs.getInt("student_id"),
                            rs.getInt("budget_month"),
                            rs.getInt("budget_year"),
                            rs.getDouble("limit_amount"));
                }
            }
        }
        return null;
    }

    // CREATE or UPDATE the budget for a month
    public void saveBudget(Budget b) throws SQLException {
        Budget existing = getBudget(b.getStudentId(), b.getBudgetMonth(), b.getBudgetYear());
        try (Connection con = DBConnection.getConnection()) {
            if (existing == null) {
                String sql = "INSERT INTO budget (student_id, budget_month, budget_year, limit_amount) VALUES (?, ?, ?, ?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setInt(1, b.getStudentId());
                    ps.setInt(2, b.getBudgetMonth());
                    ps.setInt(3, b.getBudgetYear());
                    ps.setDouble(4, b.getLimitAmount());
                    ps.executeUpdate();
                }
            } else {
                String sql = "UPDATE budget SET limit_amount = ? WHERE budget_id = ?";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    ps.setDouble(1, b.getLimitAmount());
                    ps.setInt(2, existing.getBudgetId());
                    ps.executeUpdate();
                }
            }
        }
    }
}