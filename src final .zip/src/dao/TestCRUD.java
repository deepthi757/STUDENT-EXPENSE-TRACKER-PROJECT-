/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import Model.Expense;
import java.time.LocalDate;

public class TestCRUD {
    public static void main(String[] args) {
        try {
            ExpenseDAO dao = new ExpenseDAO();

            // CREATE
            dao.addExpense(new Expense(0, 1, 3, 50.0, "Test notebook", LocalDate.now()));
            System.out.println("After ADD:");
            printAll(dao);

            // find the row we just added
            int id = 0;
            for (Expense e : dao.getAllExpenses()) {
                if (e.getDescription().equals("Test notebook")) {
                    id = e.getExpenseId();
                }
            }

            // UPDATE
            dao.updateExpense(new Expense(id, 1, 3, 99.0, "Test notebook (edited)", LocalDate.now()));
            System.out.println("After UPDATE:");
            printAll(dao);

            // DELETE
            dao.deleteExpense(id);
            System.out.println("After DELETE:");
            printAll(dao);

        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    private static void printAll(ExpenseDAO dao) throws Exception {
        for (Expense e : dao.getAllExpenses()) {
            System.out.println("  " + e.getDetails());
        }
    }
}
