/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import Model.Expense;
import java.time.LocalDate;

public class TestDAO {
    public static void main(String[] args) {
        try {
            ExpenseDAO dao = new ExpenseDAO();

            dao.addExpense(new Expense(0, 1, 2, 80.0, "Swiggy dinner", LocalDate.now()));

            for (Expense e : dao.getAllExpenses()) {
                System.out.println(e.getDetails());
            }

            LocalDate today = LocalDate.now();
            System.out.println("Monthly total: "
                    + dao.getMonthlyTotal(1, today.getMonthValue(), today.getYear()));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}