/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

import Model.Budget;
import Model.Category;
import Model.Expense;
import dao.BudgetDAO;
import dao.CategoryDAO;
import dao.ExpenseDAO;
import exception.BudgetExceededException;
import exception.InvalidAmountException;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class ExpenseForm extends JFrame {

    private static final int STUDENT_ID = 1;   // the app uses one fixed student

    private final ExpenseDAO expenseDAO = new ExpenseDAO();
    private final CategoryDAO categoryDAO = new CategoryDAO();
    private final BudgetDAO budgetDAO = new BudgetDAO();
    private List<Category> categories = new ArrayList<>();
    private int selectedExpenseId = -1;

    private final JTextField txtAmount = new JTextField(12);
    private final JTextField txtDescription = new JTextField(12);
    private final JTextField txtDate = new JTextField(12);
    private final JComboBox<String> cmbCategory = new JComboBox<>();
    private final JLabel lblTotal = new JLabel("Spent this month: Rs.0");
    private final JLabel lblBudget = new JLabel("Remaining: Rs.0");
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Category", "Description", "Amount", "Date"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tblExpenses = new JTable(tableModel);

    public ExpenseForm() {
        setTitle("Student Expense Tracker");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel form = new JPanel(new GridLayout(4, 2, 8, 8));
        form.add(new JLabel("Amount"));
        form.add(txtAmount);
        form.add(new JLabel("Description"));
        form.add(txtDescription);
        form.add(new JLabel("Date (yyyy-mm-dd)"));
        form.add(txtDate);
        form.add(new JLabel("Category"));
        form.add(cmbCategory);

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");
        JButton btnRefresh = new JButton("Refresh");
        JPanel buttons = new JPanel(new GridLayout(4, 1, 8, 8));
        buttons.add(btnAdd);
        buttons.add(btnUpdate);
        buttons.add(btnDelete);
        buttons.add(btnRefresh);

        JPanel left = new JPanel(new BorderLayout(0, 16));
        left.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        left.add(form, BorderLayout.NORTH);
        left.add(buttons, BorderLayout.CENTER);

        JPanel summary = new JPanel(new GridLayout(1, 2, 8, 8));
        summary.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        summary.add(lblTotal);
        summary.add(lblBudget);

        tblExpenses.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblExpenses.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFormFromSelectedRow();
            }
        });

        add(left, BorderLayout.WEST);
        add(new JScrollPane(tblExpenses), BorderLayout.CENTER);
        add(summary, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> onAdd());
        btnUpdate.addActionListener(e -> onUpdate());
        btnDelete.addActionListener(e -> onDelete());
        btnRefresh.addActionListener(e -> onRefresh());

        txtDate.setText(LocalDate.now().toString());
        loadCategories();
        loadExpenses();

        setSize(850, 480);
        setLocationRelativeTo(null);
    }

    // ---------- button actions ----------

    private void onAdd() {
        try {
            Expense expense = readExpenseFromForm(0);
            expenseDAO.addExpense(expense);
            clearForm();
            loadExpenses();
            checkBudgetFor(expense.getDate());
        } catch (InvalidAmountException | IllegalArgumentException ex) {
            showWarning(ex.getMessage());
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private void onUpdate() {
        if (selectedExpenseId < 0) {
            showWarning("Click a row in the table first, change the fields, then press Update.");
            return;
        }
        try {
            Expense expense = readExpenseFromForm(selectedExpenseId);
            expenseDAO.updateExpense(expense);
            clearForm();
            loadExpenses();
            checkBudgetFor(expense.getDate());
        } catch (InvalidAmountException | IllegalArgumentException ex) {
            showWarning(ex.getMessage());
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private void onDelete() {
        if (selectedExpenseId < 0) {
            showWarning("Click a row in the table first, then press Delete.");
            return;
        }
        int choice = JOptionPane.showConfirmDialog(this, "Delete this expense?",
                "Confirm delete", JOptionPane.YES_NO_OPTION);
        if (choice != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            expenseDAO.deleteExpense(selectedExpenseId);
            clearForm();
            loadExpenses();
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private void onRefresh() {
        clearForm();
        loadCategories();
        loadExpenses();
    }

    // ---------- helpers ----------

    private void loadCategories() {
        try {
            categories = categoryDAO.getAllCategories();
            cmbCategory.removeAllItems();
            for (Category c : categories) {
                cmbCategory.addItem(c.getName());
            }
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private String categoryName(int categoryId) {
        for (Category c : categories) {
            if (c.getCategoryId() == categoryId) {
                return c.getName();
            }
        }
        return "?";
    }

    private void loadExpenses() {
        try {
            tableModel.setRowCount(0);
            for (Expense e : expenseDAO.getAllExpenses()) {
                tableModel.addRow(new Object[]{
                    e.getExpenseId(), categoryName(e.getCategoryId()),
                    e.getDescription(), e.getAmount(), e.getDate()});
            }
            updateSummary();
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private void updateSummary() throws SQLException {
        LocalDate today = LocalDate.now();
        double total = expenseDAO.getMonthlyTotal(STUDENT_ID, today.getMonthValue(), today.getYear());
        lblTotal.setText("Spent this month: Rs." + String.format("%.2f", total));
        Budget budget = budgetDAO.getBudget(STUDENT_ID, today.getMonthValue(), today.getYear());
        if (budget == null) {
            lblBudget.setText("No budget set for this month");
        } else {
            lblBudget.setText("Remaining: Rs." + String.format("%.2f", budget.getRemaining(total)));
        }
    }

    private Expense readExpenseFromForm(int expenseId) throws InvalidAmountException {
        double amount;
        try {
            amount = Double.parseDouble(txtAmount.getText().trim());
        } catch (NumberFormatException ex) {
            throw new InvalidAmountException("Please enter the amount as a number.");
        }
        if (amount <= 0) {
            throw new InvalidAmountException("Amount must be greater than zero.");
        }
        String description = txtDescription.getText().trim();
        if (description.isEmpty()) {
            throw new IllegalArgumentException("Please enter a description.");
        }
        LocalDate date;
        try {
            date = LocalDate.parse(txtDate.getText().trim());
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Date must be in yyyy-mm-dd format, for example 2026-11-02.");
        }
        int index = cmbCategory.getSelectedIndex();
        if (index < 0 || index >= categories.size()) {
            throw new IllegalArgumentException("Please choose a category.");
        }
        return new Expense(expenseId, STUDENT_ID, categories.get(index).getCategoryId(),
                amount, description, date);
    }

    private void checkBudgetFor(LocalDate date) {
        try {
            double total = expenseDAO.getMonthlyTotal(STUDENT_ID, date.getMonthValue(), date.getYear());
            Budget budget = budgetDAO.getBudget(STUDENT_ID, date.getMonthValue(), date.getYear());
            if (budget != null) {
                budget.checkBudget(total);
            }
        } catch (BudgetExceededException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Budget warning",
                    JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            showDbError(ex);
        }
    }

    private void fillFormFromSelectedRow() {
        int row = tblExpenses.getSelectedRow();
        if (row < 0) {
            selectedExpenseId = -1;
            return;
        }
        selectedExpenseId = (Integer) tableModel.getValueAt(row, 0);
        cmbCategory.setSelectedItem(String.valueOf(tableModel.getValueAt(row, 1)));
        txtDescription.setText(String.valueOf(tableModel.getValueAt(row, 2)));
        txtAmount.setText(String.valueOf(tableModel.getValueAt(row, 3)));
        txtDate.setText(String.valueOf(tableModel.getValueAt(row, 4)));
    }

    private void clearForm() {
        tblExpenses.clearSelection();
        selectedExpenseId = -1;
        txtAmount.setText("");
        txtDescription.setText("");
        txtDate.setText(LocalDate.now().toString());
        if (cmbCategory.getItemCount() > 0) {
            cmbCategory.setSelectedIndex(0);
        }
    }

    private void showDbError(SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(this, message, "Please check", JOptionPane.WARNING_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ExpenseForm().setVisible(true));
    }
}
